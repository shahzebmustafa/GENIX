# GENIX
GENIX: A GENI-based IXP Emulation

## Guidlines for testing
Use /private/GENIX_8_private.xml or /public/GENIX_8_public.xml as the request rspec for Private and Public topology respectively.

*This is a work in progress, the code files do not guarantee perfect execution*
