# GENIX
GENIX: A GENI-based IXP Emulation

## Guidlines for testing
### Step One:
Get access to GENI portal. You will need to log in using an affiliated college/university.

### Step Two:
Create a slice and add resources by using the /Public/GENIX/public_8.xml or /Private/GENIX/private_8.xml as the request rsepc for public or private peering topologies respectively.

### Step Three:
Wait till the nodes are ready and configured. Once the status changes to ready, the setup is complete.

*This is a work in progress, the code files do not guarantee perfect execution*
